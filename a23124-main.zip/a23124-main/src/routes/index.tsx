import { createFileRoute } from "@tanstack/react-router";
import wechatQr from "@/assets/wechat-qr.asset.json";
import contractSample from "@/assets/contract-sample.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "应收账款追收 | Взыскание задолженности в РФ и Казахстане" },
      {
        name: "description",
        content:
          "Юридическое сопровождение взыскания дебиторской задолженности в РФ и Казахстане. Оплата по результату. 追收应收账款 — 按结果收费.",
      },
      { property: "og:title", content: "应收账款追收 | Взыскание задолженности" },
      {
        property: "og:description",
        content:
          "Полное юридическое сопровождение взыскания долгов в РФ и Казахстане. 追收应收账款.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="bg-background text-foreground">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Inter:wght@300;400;500;600;700&family=Noto+Serif+SC:wght@400;600;700&display=swap');

        :root {
          --brand-primary: #0F2545;
          --brand-primary-dark: #08152B;
          --brand-accent: #B8924F;
          --brand-accent-light: #D4B074;
          --brand-text: #1F2937;
          --brand-text-light: #6B7280;
          --brand-bg-light: #F7F5F0;
          --brand-border: #E5E7EB;
        }
        .bilingual-site { font-family: 'Inter', 'Microsoft YaHei', sans-serif; color: var(--brand-text); line-height: 1.7; font-weight: 400; }
        .bilingual-site .container { max-width: 1180px; margin: 0 auto; padding: 0 24px; }
        .bilingual-site .serif { font-family: 'Libre Baskerville', 'Noto Serif SC', serif; }

        /* Top bar */
        .bilingual-site .topbar { background: var(--brand-primary-dark); color: #cbd5e1; font-size: 0.82rem; padding: 8px 0; }
        .bilingual-site .topbar .container { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 8px; }
        .bilingual-site .topbar a { color: var(--brand-accent-light); text-decoration: none; }

        /* Nav */
        .bilingual-site .nav { background: white; border-bottom: 1px solid var(--brand-border); padding: 18px 0; position: sticky; top: 0; z-index: 50; }
        .bilingual-site .nav .container { display: flex; justify-content: space-between; align-items: center; gap: 24px; flex-wrap: wrap; }
        .bilingual-site .brand { display: flex; align-items: center; gap: 14px; }
        .bilingual-site .brand-mark { width: 44px; height: 44px; background: var(--brand-primary); color: var(--brand-accent); display: flex; align-items: center; justify-content: center; font-family: 'Libre Baskerville', serif; font-weight: 700; font-size: 1.25rem; border: 1.5px solid var(--brand-accent); letter-spacing: 1px; }
        .bilingual-site .brand-text { line-height: 1.2; }
        .bilingual-site .brand-text .ru { font-family: 'Libre Baskerville', serif; font-weight: 700; color: var(--brand-primary); font-size: 1.05rem; }
        .bilingual-site .brand-text .cn { font-size: 0.82rem; color: var(--brand-text-light); margin-top: 2px; }
        .bilingual-site .nav-links { display: flex; gap: 28px; align-items: center; }
        .bilingual-site .nav-links a { color: var(--brand-text); text-decoration: none; font-size: 0.92rem; font-weight: 500; transition: color 0.2s; }
        .bilingual-site .nav-links a:hover { color: var(--brand-accent); }
        .bilingual-site .nav-cta { background: var(--brand-primary); color: white !important; padding: 10px 20px; font-size: 0.85rem !important; letter-spacing: 0.3px; }
        .bilingual-site .nav-cta:hover { background: var(--brand-accent) !important; color: white !important; }

        /* Hero */
        .bilingual-site .hero { background: linear-gradient(135deg, var(--brand-primary-dark) 0%, var(--brand-primary) 100%); color: white; padding: 100px 0 110px; position: relative; overflow: hidden; }
        .bilingual-site .hero::before { content: ''; position: absolute; top: 0; right: -10%; width: 60%; height: 100%; background: radial-gradient(circle at center, rgba(184,146,79,0.12) 0%, transparent 60%); }
        .bilingual-site .hero .container { position: relative; z-index: 1; }
        .bilingual-site .hero .eyebrow { display: inline-block; color: var(--brand-accent-light); font-size: 0.78rem; letter-spacing: 3px; text-transform: uppercase; margin-bottom: 24px; padding-bottom: 10px; border-bottom: 1px solid var(--brand-accent); }
        .bilingual-site .hero h1 { font-family: 'Libre Baskerville', 'Noto Serif SC', serif; font-size: 2.85rem; font-weight: 700; line-height: 1.2; margin-bottom: 18px; max-width: 850px; }
        .bilingual-site .hero h1 .cn-line { display: block; font-family: 'Noto Serif SC', serif; font-size: 1.55rem; font-weight: 600; color: var(--brand-accent-light); margin-bottom: 14px; letter-spacing: 1px; }
        .bilingual-site .hero p.lead { font-size: 1.08rem; color: #cbd5e1; max-width: 720px; margin-bottom: 36px; line-height: 1.7; }
        .bilingual-site .hero-cta { display: flex; gap: 16px; flex-wrap: wrap; }
        .bilingual-site .btn { display: inline-flex; align-items: center; gap: 10px; padding: 15px 30px; font-weight: 600; font-size: 0.95rem; text-decoration: none; transition: all 0.25s; border: 1.5px solid transparent; cursor: pointer; }
        .bilingual-site .btn-primary { background: var(--brand-accent); color: white; }
        .bilingual-site .btn-primary:hover { background: var(--brand-accent-light); transform: translateY(-1px); }
        .bilingual-site .btn-outline { background: transparent; color: white; border-color: rgba(255,255,255,0.3); }
        .bilingual-site .btn-outline:hover { border-color: var(--brand-accent); color: var(--brand-accent-light); }

        /* Stats strip */
        .bilingual-site .stats { background: white; border-bottom: 1px solid var(--brand-border); }
        .bilingual-site .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); }
        .bilingual-site .stat { padding: 36px 24px; text-align: center; border-right: 1px solid var(--brand-border); }
        .bilingual-site .stat:last-child { border-right: none; }
        .bilingual-site .stat .num { font-family: 'Libre Baskerville', serif; font-size: 2.2rem; font-weight: 700; color: var(--brand-primary); line-height: 1; }
        .bilingual-site .stat .num .accent { color: var(--brand-accent); }
        .bilingual-site .stat .label { font-size: 0.82rem; color: var(--brand-text-light); margin-top: 10px; line-height: 1.4; }

        /* Section base */
        .bilingual-site section { padding: 90px 0; }
        .bilingual-site .section-head { text-align: center; max-width: 760px; margin: 0 auto 60px; }
        .bilingual-site .section-eyebrow { color: var(--brand-accent); font-size: 0.78rem; letter-spacing: 3px; text-transform: uppercase; margin-bottom: 14px; font-weight: 600; }
        .bilingual-site .section-head h2 { font-family: 'Libre Baskerville', 'Noto Serif SC', serif; font-size: 2.2rem; color: var(--brand-primary); font-weight: 700; line-height: 1.25; margin-bottom: 12px; }
        .bilingual-site .section-head h2 .cn { display: block; font-family: 'Noto Serif SC', serif; font-size: 1.25rem; color: var(--brand-text-light); font-weight: 600; margin-top: 8px; }
        .bilingual-site .section-head p { color: var(--brand-text-light); font-size: 1.02rem; }

        /* About / services */
        .bilingual-site .about { background: var(--brand-bg-light); }
        .bilingual-site .about-grid { display: grid; grid-template-columns: 1.1fr 1fr; gap: 60px; align-items: center; }
        .bilingual-site .about-text p { color: var(--brand-text); margin-bottom: 18px; font-size: 1.02rem; }
        .bilingual-site .about-text p.cn { color: var(--brand-text-light); font-size: 0.98rem; }
        .bilingual-site .feature-list { display: grid; gap: 18px; }
        .bilingual-site .feature { background: white; padding: 24px 26px; border-left: 3px solid var(--brand-accent); box-shadow: 0 1px 3px rgba(15,37,69,0.06); }
        .bilingual-site .feature h4 { font-family: 'Libre Baskerville', serif; color: var(--brand-primary); font-size: 1.05rem; margin-bottom: 6px; }
        .bilingual-site .feature p { font-size: 0.92rem; color: var(--brand-text-light); margin: 0; }
        .bilingual-site .feature .cn { font-size: 0.85rem; color: var(--brand-text-light); margin-top: 4px; }

        /* Work plan */
        .bilingual-site .work-plan { background: white; }
        .bilingual-site .steps-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }
        .bilingual-site .step-card { background: white; padding: 36px 28px; border: 1px solid var(--brand-border); position: relative; transition: all 0.25s; }
        .bilingual-site .step-card:hover { border-color: var(--brand-accent); transform: translateY(-3px); box-shadow: 0 12px 30px rgba(15,37,69,0.08); }
        .bilingual-site .step-number { font-family: 'Libre Baskerville', serif; font-size: 2.6rem; color: var(--brand-accent); font-weight: 700; line-height: 1; margin-bottom: 18px; }
        .bilingual-site .step-card h4 { font-family: 'Libre Baskerville', 'Noto Serif SC', serif; font-size: 1.15rem; color: var(--brand-primary); margin-bottom: 4px; font-weight: 700; }
        .bilingual-site .step-card .h-cn { color: var(--brand-text-light); font-size: 0.9rem; margin-bottom: 16px; font-weight: 500; }
        .bilingual-site .step-card p { font-size: 0.9rem; color: var(--brand-text); margin-bottom: 10px; }
        .bilingual-site .step-card p.cn { color: var(--brand-text-light); font-size: 0.85rem; }

        /* Pricing banner */
        .bilingual-site .price-banner { background: var(--brand-primary); color: white; padding: 60px 0; }
        .bilingual-site .price-banner .container { display: flex; align-items: center; justify-content: space-between; gap: 40px; flex-wrap: wrap; }
        .bilingual-site .price-banner h3 { font-family: 'Libre Baskerville', serif; font-size: 1.8rem; margin-bottom: 8px; }
        .bilingual-site .price-banner h3 .accent { color: var(--brand-accent-light); }
        .bilingual-site .price-banner p { color: #cbd5e1; max-width: 600px; }

        /* Sample */
        .bilingual-site .sample-section { background: var(--brand-bg-light); }
        .bilingual-site .sample-card { background: white; max-width: 720px; margin: 0 auto; padding: 50px 40px; text-align: center; border: 1px solid var(--brand-border); border-top: 3px solid var(--brand-accent); }
        .bilingual-site .sample-icon { width: 64px; height: 64px; margin: 0 auto 24px; background: var(--brand-bg-light); display: flex; align-items: center; justify-content: center; font-size: 1.8rem; }
        .bilingual-site .sample-card h3 { font-family: 'Libre Baskerville', serif; color: var(--brand-primary); font-size: 1.6rem; margin-bottom: 10px; }
        .bilingual-site .sample-card .h-cn { color: var(--brand-text-light); font-size: 1rem; margin-bottom: 24px; }
        .bilingual-site .sample-card p.desc { color: var(--brand-text-light); margin-bottom: 30px; font-size: 0.95rem; }

        /* Contacts */
        .bilingual-site .contacts { background: white; }
        .bilingual-site .contact-grid { display: grid; grid-template-columns: 1.1fr 1fr; gap: 60px; max-width: 980px; margin: 0 auto; align-items: center; }
        .bilingual-site .contact-block { display: grid; gap: 22px; }
        .bilingual-site .contact-item { display: flex; gap: 18px; align-items: flex-start; padding: 22px 24px; background: var(--brand-bg-light); border-left: 3px solid var(--brand-accent); }
        .bilingual-site .contact-item .icon { font-size: 1.4rem; }
        .bilingual-site .contact-item strong { display: block; font-family: 'Libre Baskerville', serif; color: var(--brand-primary); font-size: 0.95rem; margin-bottom: 4px; text-transform: none; letter-spacing: 0; }
        .bilingual-site .contact-item .cn { font-size: 0.8rem; color: var(--brand-text-light); margin-bottom: 8px; }
        .bilingual-site .contact-item a, .bilingual-site .contact-item span.value { color: var(--brand-text); text-decoration: none; font-size: 1.05rem; font-weight: 600; }
        .bilingual-site .contact-item a:hover { color: var(--brand-accent); }
        .bilingual-site .qr-card { background: var(--brand-bg-light); padding: 32px; text-align: center; border: 1px solid var(--brand-border); }
        .bilingual-site .qr-card img { max-width: 220px; width: 100%; display: block; margin: 0 auto; background: white; padding: 12px; border: 1px solid var(--brand-border); }
        .bilingual-site .qr-card .label { font-family: 'Libre Baskerville', serif; color: var(--brand-primary); font-size: 0.95rem; margin-top: 16px; font-weight: 700; }
        .bilingual-site .qr-card .cn { font-size: 0.82rem; color: var(--brand-text-light); margin-top: 4px; }

        /* Footer */
        .bilingual-site footer { background: var(--brand-primary-dark); color: #94a3b8; padding: 50px 0 24px; }
        .bilingual-site .footer-grid { display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 40px; margin-bottom: 36px; }
        .bilingual-site .footer-brand .ru { font-family: 'Libre Baskerville', serif; color: white; font-size: 1.15rem; margin-bottom: 6px; }
        .bilingual-site .footer-brand .cn { color: #cbd5e1; font-size: 0.9rem; margin-bottom: 16px; }
        .bilingual-site .footer-brand p { font-size: 0.85rem; line-height: 1.6; }
        .bilingual-site footer h5 { font-family: 'Libre Baskerville', serif; color: white; font-size: 0.95rem; margin-bottom: 14px; }
        .bilingual-site footer a { color: #94a3b8; text-decoration: none; font-size: 0.88rem; display: block; margin-bottom: 8px; transition: color 0.2s; }
        .bilingual-site footer a:hover { color: var(--brand-accent-light); }
        .bilingual-site .footer-bottom { border-top: 1px solid rgba(255,255,255,0.08); padding-top: 24px; text-align: center; font-size: 0.8rem; }

        @media (max-width: 900px) {
          .bilingual-site .hero h1 { font-size: 2rem; }
          .bilingual-site .hero h1 .cn-line { font-size: 1.2rem; }
          .bilingual-site .nav-links { display: none; }
          .bilingual-site .stats-grid { grid-template-columns: repeat(2, 1fr); }
          .bilingual-site .stat:nth-child(2) { border-right: none; }
          .bilingual-site .stat:nth-child(1), .bilingual-site .stat:nth-child(2) { border-bottom: 1px solid var(--brand-border); }
          .bilingual-site .about-grid, .bilingual-site .contact-grid { grid-template-columns: 1fr; gap: 40px; }
          .bilingual-site .steps-grid { grid-template-columns: repeat(2, 1fr); }
          .bilingual-site .footer-grid { grid-template-columns: 1fr; }
          .bilingual-site section { padding: 60px 0; }
        }
        @media (max-width: 540px) {
          .bilingual-site .steps-grid { grid-template-columns: 1fr; }
          .bilingual-site .section-head h2 { font-size: 1.7rem; }
        }
      `}</style>

      <div className="bilingual-site">
        {/* Top bar */}
        <div className="topbar">
          <div className="container">
            <span>📍 БЦ «Высоцкий», ул. Малышева, 51, Екатеринбург · 叶卡捷琳堡</span>
            <span>
              <a href="tel:+79222917133">+7 922 291-71-33</a> · <a href="mailto:creditwill@yandex.ru">creditwill@yandex.ru</a>
            </span>
          </div>
        </div>

        {/* Nav */}
        <nav className="nav">
          <div className="container">
            <div className="brand">
              <div className="brand-mark">ЮБ</div>
              <div className="brand-text">
                <div className="ru">Юридическое Бюро</div>
                <div className="cn">俄罗斯"法律服务"有限责任公司</div>
              </div>
            </div>
            <div className="nav-links">
              <a href="#services">Услуги · 服务</a>
              <a href="#process">Процесс · 流程</a>
              <a href="#sample">Договор · 合同</a>
              <a href="#contacts">Контакты · 联系</a>
              <a href="#contacts" className="nav-cta">Консультация</a>
            </div>
          </div>
        </nav>

        {/* Hero */}
        <section className="hero" style={{ padding: "100px 0 110px" }}>
          <div className="container">
            <div className="eyebrow">Debt Recovery · RU & KZ · 应收账款追收</div>
            <h1>
              <span className="cn-line">在俄罗斯与哈萨克斯坦境内追收企业债务</span>
              Взыскание дебиторской задолженности в&nbsp;РФ и&nbsp;Казахстане
            </h1>
            <p className="lead">
              Полное юридическое сопровождение взыскания долгов и&nbsp;исполнение решений международного арбитража и&nbsp;национальных судов. Работаем&nbsp;по&nbsp;принципу&nbsp;«оплата&nbsp;по&nbsp;результату».
              <br />
              <br />
              全方位法律支持 — 协助中国企业追回俄罗斯及哈萨克斯坦境内应收账款，按结果收费。
            </p>
            <div className="hero-cta">
              <a href="#contacts" className="btn btn-primary">Получить консультацию · 免费咨询</a>
              <a href="#process" className="btn btn-outline">Как мы работаем →</a>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="stats" style={{ padding: 0 }}>
          <div className="stats-grid">
            <div className="stat">
              <div className="num">15<span className="accent">%</span></div>
              <div className="label">Комиссия от взысканной суммы<br/>仅收取15%佣金</div>
            </div>
            <div className="stat">
              <div className="num">0<span className="accent">₽</span></div>
              <div className="label">Предоплата · нет результата — нет оплаты<br/>无效果 — 不收费</div>
            </div>
            <div className="stat">
              <div className="num">2</div>
              <div className="label">Юрисдикции: РФ и&nbsp;Казахстан<br/>俄罗斯 · 哈萨克斯坦</div>
            </div>
            <div className="stat">
              <div className="num">RU<span className="accent">/</span>CN</div>
              <div className="label">Двуязычное сопровождение<br/>中俄双语服务</div>
            </div>
          </div>
        </section>

        {/* About / Services */}
        <section className="about" id="services">
          <div className="container">
            <div className="section-head">
              <div className="section-eyebrow">Наши услуги</div>
              <h2>
                Защита коммерческих интересов
                <span className="cn">保护您的商业利益</span>
              </h2>
            </div>

            <div className="about-grid">
              <div className="about-text">
                <p>
                  Юридическое Бюро оказывает услуги по полному юридическому сопровождению взыскания дебиторской задолженности на территории Российской Федерации и&nbsp;Республики Казахстан, а&nbsp;также по исполнению судебных актов международного арбитража и&nbsp;национальных судов.
                </p>
                <p className="cn">
                  我们在俄罗斯联邦和哈萨克斯坦境内提供全方位的应收账款追收法律支持服务，并协助执行针对您违约交易相对方的国际仲裁和国家法院司法裁决。
                </p>
                <p>
                  Поможем вернуть недоплату и&nbsp;задолженности с&nbsp;ваших недобросовестных партнёров или&nbsp;исполнить уже имеющееся решение&nbsp;суда.
                </p>
              </div>

              <div className="feature-list">
                <div className="feature">
                  <h4>Досудебное взыскание</h4>
                  <p>Претензионная работа, переговоры, фиксация задолженности.</p>
                  <p className="cn">庭外追收 — 索赔、谈判、债务确认</p>
                </div>
                <div className="feature">
                  <h4>Судебное представительство</h4>
                  <p>Арбитражные и&nbsp;гражданские процессы в&nbsp;РФ и&nbsp;Казахстане.</p>
                  <p className="cn">司法代理 — 俄罗斯及哈萨克斯坦法院诉讼</p>
                </div>
                <div className="feature">
                  <h4>Исполнение решений суда</h4>
                  <p>Работа с&nbsp;ФССП, арест имущества и&nbsp;счетов должника.</p>
                  <p className="cn">判决执行 — 与执行机关合作，查封资产及账户</p>
                </div>
                <div className="feature">
                  <h4>Признание иностранных решений</h4>
                  <p>Исполнение решений международного арбитража на&nbsp;территории РФ и&nbsp;РК.</p>
                  <p className="cn">承认与执行 — 国际仲裁裁决的境内执行</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Work plan */}
        <section className="work-plan" id="process">
          <div className="container">
            <div className="section-head">
              <div className="section-eyebrow">Процесс работы</div>
              <h2>
                Четыре этапа сотрудничества
                <span className="cn">合作流程 · 四个步骤</span>
              </h2>
              <p>Прозрачная процедура от&nbsp;первичного анализа до&nbsp;перечисления взысканных средств клиенту.</p>
            </div>

            <div className="steps-grid">
              <div className="step-card">
                <div className="step-number">01</div>
                <h4>Оценка дела</h4>
                <div className="h-cn">案件评估</div>
                <p>Проверяем должника на&nbsp;предмет имущества и&nbsp;денежных средств.</p>
                <p className="cn">您发送债务人信息及欠款金额，我们进行全面背景调查。</p>
              </div>
              <div className="step-card">
                <div className="step-number">02</div>
                <h4>Подписание договора</h4>
                <div className="h-cn">签署合同</div>
                <p>Если есть за&nbsp;счёт чего взыскать долг — заключаем договор.</p>
                <p className="cn">若债务人具备偿还能力，双方签署风险代理服务协议。</p>
              </div>
              <div className="step-card">
                <div className="step-number">03</div>
                <h4>Судебные процедуры</h4>
                <div className="h-cn">司法程序</div>
                <p>Проходим все необходимые судебные и&nbsp;исполнительные стадии.</p>
                <p className="cn">由专业律师团队启动并推进所有法律及司法诉讼程序。</p>
              </div>
              <div className="step-card">
                <div className="step-number">04</div>
                <h4>Перечисление средств</h4>
                <div className="h-cn">成功回款</div>
                <p>Перечисляем взысканную сумму за&nbsp;минусом комиссии 15%.</p>
                <p className="cn">扣除15%佣金后，将剩余款项汇入您的账户。</p>
              </div>
            </div>
          </div>
        </section>

        {/* Pricing banner */}
        <section className="price-banner" style={{ padding: "60px 0" }}>
          <div className="container">
            <div>
              <h3>Оплата <span className="accent">по&nbsp;результату</span> · 按结果收费</h3>
              <p>Никакой предоплаты. Наша комиссия — 15% от&nbsp;фактически взысканной суммы. 无前期费用，仅在成功追回后收取15%佣金。</p>
            </div>
            <a href="#contacts" className="btn btn-primary">Обсудить ваш кейс →</a>
          </div>
        </section>

        {/* Sample */}
        <section className="sample-section" id="sample">
          <div className="container">
            <div className="sample-card">
              <div className="sample-icon">📄</div>
              <h3>Образец договора</h3>
              <div className="h-cn">合同样本</div>
              <p className="desc">
                Двуязычный шаблон договора о&nbsp;взыскании дебиторской задолженности (русский&nbsp;/ китайский). Ознакомьтесь с&nbsp;условиями до&nbsp;консультации.
                <br />
                双语合同模板（中文 / 俄文），方便您提前了解合作条款。
              </p>
              <a
                href={contractSample.url}
                download="ДОГОВОР_О_ВЗЫСКАНИИ_ДЗ.docx"
                className="btn btn-primary"
              >
                Скачать образец · 下载样本
              </a>
            </div>
          </div>
        </section>

        {/* Contacts */}
        <section className="contacts" id="contacts">
          <div className="container">
            <div className="section-head">
              <div className="section-eyebrow">Свяжитесь с нами</div>
              <h2>
                Контакты
                <span className="cn">联系方式</span>
              </h2>
              <p>Первичная консультация и&nbsp;оценка перспектив дела&nbsp;— бесплатно. 免费首次咨询。</p>
            </div>

            <div className="contact-grid">
              <div className="contact-block">
                <div className="contact-item">
                  <div className="icon">📞</div>
                  <div>
                    <strong>Телефон</strong>
                    <div className="cn">电话 · WhatsApp</div>
                    <a href="tel:+79222917133">+7 922 291-71-33</a>
                  </div>
                </div>
                <div className="contact-item">
                  <div className="icon">✉️</div>
                  <div>
                    <strong>Электронная почта</strong>
                    <div className="cn">邮箱</div>
                    <a href="mailto:creditwill@yandex.ru">creditwill@yandex.ru</a>
                  </div>
                </div>
                <div className="contact-item">
                  <div className="icon">📍</div>
                  <div>
                    <strong>Офис</strong>
                    <div className="cn">办公地址</div>
                    <span className="value">БЦ «Высоцкий», ул.&nbsp;Малышева, 51, Екатеринбург</span>
                  </div>
                </div>
              </div>

              <div className="qr-card">
                <img src={wechatQr.url} alt="WeChat QR" />
                <div className="label">WeChat</div>
                <div className="cn">扫码添加微信</div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer>
          <div className="container">
            <div className="footer-grid">
              <div className="footer-brand">
                <div className="ru">ООО «Юридическое Бюро»</div>
                <div className="cn">俄罗斯"法律服务"有限责任公司</div>
                <p>Взыскание дебиторской задолженности в&nbsp;РФ и&nbsp;Казахстане. Сопровождение исполнения решений международного арбитража.</p>
              </div>
              <div>
                <h5>Навигация</h5>
                <a href="#services">Услуги · 服务</a>
                <a href="#process">Процесс · 流程</a>
                <a href="#sample">Договор · 合同</a>
                <a href="#contacts">Контакты · 联系</a>
              </div>
              <div>
                <h5>Контакты</h5>
                <a href="tel:+79222917133">+7 922 291-71-33</a>
                <a href="mailto:creditwill@yandex.ru">creditwill@yandex.ru</a>
                <a>БЦ «Высоцкий», Екатеринбург</a>
              </div>
            </div>
            <div className="footer-bottom">
              © 2026 ООО «Юридическое Бюро». Все права защищены. · 保留所有权利.
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
